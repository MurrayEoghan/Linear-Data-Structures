public class MyDoubleDynamicStack<T> implements MyStack<T> {
	private MyDoubleLinkedNode<T> tail;
	private MyDoubleLinkedNode<T> head;
	private int numItems;

	public MyDoubleDynamicStack(){

		this.head = null;
		this.tail = null;
		this.numItems = 0;
		
	}


	public boolean isEmpty(){
		return numItems <= 0;
	}
	

	public T first(){
		MyDoubleLinkedNode<T> first;
		first = head;
		return (T) first.getInfo();
	}

	public void addByFirst(T element){
		MyDoubleLinkedNode<T> currentNode = null;
		MyDoubleLinkedNode<T> newNode = null;
		if (head == null) {
			newNode = new MyDoubleLinkedNode<T>(null, element, null);
			head = newNode;
			numItems ++;
		}
		else if(head != null) {
			newNode = new MyDoubleLinkedNode<T>(null, element, null);
			currentNode = head;
			head = newNode;
			head.right = currentNode;
			numItems ++;

	}
	else {
		System.out.println("Error occured.");
	}
	}	

	public void removeByFirst(){

		if (!isEmpty()) {
			head = head.right;
			
			this.numItems --;
		}
		else {
			System.out.println("Error Occured. List Empty");
		}

	}


	public T last(){

		MyDoubleLinkedNode<T> last = tail;
		
		return last.getInfo();
	}


	public void addByLast(T element){
		MyDoubleLinkedNode<T> currentNode = null;
		MyDoubleLinkedNode<T> newNode = null;
		if (tail == null) {
			
		newNode = new MyDoubleLinkedNode<T>(null, element, null);
		this.tail = newNode;
		numItems ++;
	}
		else if (tail != null) {
			newNode = new MyDoubleLinkedNode<T>(null, element, null);
			currentNode = tail;
			tail = newNode;
			tail.left = currentNode;
			numItems ++;
		}
		else {
		System.out.println("Error occured.");
		}
	}

	public void removeByLast(){
		if (tail != null) {
		tail = tail.left;
		numItems--;
	}
		else {
			System.out.println("Error Occured. List Empty");
		}
	}
}
