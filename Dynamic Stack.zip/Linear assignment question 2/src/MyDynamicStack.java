// Eoghan Murray - R00159241 - Assignment Question 2

/**
* ADT MyStack: Private Part<br>. 
* The class implements all the operations available in MyStack<br>
*/
public class MyDynamicStack implements MyStack {


	private int numItems;
	private MyNode head;


	public MyDynamicStack(){

		this.head = null;
		this.numItems = 0;
		
		
	}


	public boolean isEmpty(){

		return numItems<=0;
	}

	
	public int pop(){

		
		if (numItems > 0) {
			MyNode currentNode = null;
			currentNode = head;
			head = head.getNext();
			this.numItems--;
			return currentNode.getInfo();
		}
		else {
			System.out.println("Error. Stack is empty");
			return -1;
		}
			
		
		
		
	}


	public void push(int element){
		
		MyNode newNode = null;
		MyNode currentNode = null;


		if (numItems == 0) {
			currentNode = head;
			newNode = new MyNode(element, null);
			head = newNode;
			head.setNext(currentNode);
			numItems += 1;
		}
		else if (numItems > 0) {

			currentNode = head;
			newNode = new MyNode(element, null);
			head = newNode;
			head.setNext(currentNode);
			numItems += 1;
		}
		else {
			System.out.println("Couldnt push. An error has occured.");
		}
		}

	


	public void print(){
		String print = "";
		MyNode currentNode = head;
		if (numItems > 0) {
			for (int i = 0; i < numItems; i++) {
				
				print += (" "+currentNode.getInfo());
				currentNode = currentNode.getNext();
				
			}
		System.out.println(print);
		}
		else {
			System.out.println("[ ]");
		}
		
	}


	
}
