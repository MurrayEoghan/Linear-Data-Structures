import java.util.*;
/**
* ADT MyStack: Private Part<br>. 
* The class implements all the operations available in MyStack<br>
*/
public class MyStaticStack implements MyStack {


	private int items[];
	private int numItems;
	private int maxItems;

	public MyStaticStack(int m){

		this.numItems = 0;
		this.maxItems = m;
		this.items = new int[this.maxItems];
	}


	public boolean isEmpty(){


		return numItems<=0;
	}
	

	
	public int pop(){
		

		int data=0;
		if (isEmpty()) {
			System.out.println("Stack is empty.");
		}
		else {
		
		numItems--;
		data = items[numItems];
		items[numItems] = 0;
		}
		return data;
	}

	public void push(int element){
			

		if (numItems < maxItems) {
			
		
			items[numItems] = element;
			numItems++;
		}
		else {
			System.out.println("No space left in the stack.");
		}
		}
		
		
			

	public void print(){
		
		System.out.println(Arrays.toString(items));
	}
	
}
